# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 4.7.x   | :white_check_mark: |
| 3.7.x   | :white_check_mark: |
| < 3.7.0   | :x:                |

## Reporting a Vulnerability

Please visit the URL for OSSEC security contact:

https://www.ossec.net/.well-known/security.txt
